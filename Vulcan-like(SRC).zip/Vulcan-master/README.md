how NOT to make an anticheat 101

none of this code is in the current vulcan thankfully LOL
