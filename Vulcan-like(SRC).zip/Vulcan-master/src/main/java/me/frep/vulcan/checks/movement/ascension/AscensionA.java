package me.frep.vulcan.checks.movement.ascension;

public class AscensionA {
}
