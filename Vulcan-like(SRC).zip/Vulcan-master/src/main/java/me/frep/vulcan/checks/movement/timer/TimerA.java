package me.frep.vulcan.checks.movement.timer;

public class TimerA {
}
