package me.frep.vulcan.checks.movement.sprint;

public class SprintA {
}
