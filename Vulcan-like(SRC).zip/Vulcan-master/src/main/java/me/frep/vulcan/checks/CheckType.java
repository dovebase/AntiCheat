package me.frep.vulcan.checks;

public enum CheckType {

    COMBAT, MOVEMENT, PLAYER, OTHER
}
