package me.frep.vulcan.checks.movement.jesus;

public class JesusA {
}
