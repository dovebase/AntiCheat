package me.frep.vulcan.checks.movement.motion;

public class MotionA {
}
