package me.frep.vulcan.checks.movement.flight;

public class FlightA {
}
