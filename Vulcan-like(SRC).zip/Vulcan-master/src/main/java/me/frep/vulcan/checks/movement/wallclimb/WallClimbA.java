package me.frep.vulcan.checks.movement.wallclimb;

public class WallClimbA {
}
