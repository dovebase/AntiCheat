package me.frep.vulcan.checks.player.misc;

public class FastBowA {
}
