package me.frep.vulcan.checks.player.scaffold;

public class ScaffoldA {
}
