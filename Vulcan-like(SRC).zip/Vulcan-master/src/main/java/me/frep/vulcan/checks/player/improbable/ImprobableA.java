package me.frep.vulcan.checks.player.improbable;

public class ImprobableA {
}
